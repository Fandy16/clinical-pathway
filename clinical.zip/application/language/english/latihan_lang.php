<?php

$lang['title'] = 'Language Exercise';
$lang['content'] = 'This is practice using Language Class in Codeigniter. Its so easy and simple, right?';

?>